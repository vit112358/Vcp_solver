#!/bin/bash
INSTANCIA=$1;
NUM_REPETICOES=$2;
CONTADOR=0;
while [ $CONTADOR -lt $NUM_REPETICOES ]
do
	CONTADOR=$((CONTADOR+1))
	echo "Execucao No. "$CONTADOR
	echo
	java Vcp_solver $RANDOM g $INSTANCIA saida.txt
done
