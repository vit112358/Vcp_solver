#!bin/bash
echo java Vcp_solver $1 $2 $3 $4
