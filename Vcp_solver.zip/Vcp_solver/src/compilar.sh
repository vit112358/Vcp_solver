#!/bin/bash
echo
javac Vcp_solver.java
